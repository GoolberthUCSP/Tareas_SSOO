# Funcionalidad

- make: Compila los programas write.c y read.c.
- make clean: elimina elementos residuales.
- ./write a op b: op= +,-,/,'*'. a y b son números.
- ./read type: type= 'odd' o 'even'.
